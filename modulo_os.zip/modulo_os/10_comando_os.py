import os
os.system("cls")
print("Testando")
print("o")
print("envio de")
print("comandos")
print("para o SO utilizando o módulo OS")

os.system("mkdir teste1000")